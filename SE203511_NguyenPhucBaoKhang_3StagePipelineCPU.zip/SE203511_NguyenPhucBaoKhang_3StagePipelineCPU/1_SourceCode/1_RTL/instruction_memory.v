`timescale 1ns / 1ps
// FILE: instruction_memory.v
module instruction_memory #(
    parameter PROGRAM_FILE = "program.mem"
)(
    input  wire [3:0] address,
    output wire [11:0] instruction
);
    reg [11:0] mem [0:15];
    integer i;
    
    initial begin
        for (i = 0; i < 16; i = i + 1)
            mem[i] = 12'hC00; // C00 is reserved opcode NOP
        $readmemh(PROGRAM_FILE, mem);
    end
    
    assign instruction = mem[address];
endmodule