`timescale 1ns / 1ps
// FILE: program_counter.v
module program_counter (
    input  wire clk,
    input  wire rst,
    input  wire pc_en,
    input  wire [3:0] pc_next,
    output reg  [3:0] pc_out
);
    // Asynchronous reset: active high
    always @(posedge clk or posedge rst) begin
        if (rst)
            pc_out <= 4'd0;
        else if (pc_en)
            pc_out <= pc_next;
    end
endmodule