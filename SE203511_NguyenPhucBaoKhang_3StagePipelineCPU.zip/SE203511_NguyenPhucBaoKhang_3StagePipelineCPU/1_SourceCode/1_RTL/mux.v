`timescale 1ns / 1ps
// FILE: mux.v
module mux2 (
    input  wire [3:0] d0,
    input  wire [3:0] d1,
    input  wire sel,
    output wire [3:0] y
);
    assign y = (sel == 1'b1) ? d1 : d0;
endmodule