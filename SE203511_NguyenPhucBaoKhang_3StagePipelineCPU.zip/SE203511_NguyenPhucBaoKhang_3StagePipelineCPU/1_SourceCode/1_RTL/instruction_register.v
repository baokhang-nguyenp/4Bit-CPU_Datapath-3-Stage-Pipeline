`timescale 1ns / 1ps
// FILE: instruction_register.v
// IF/ID Pipeline Register
module instruction_register (
    input  wire clk,
    input  wire rst,
    input  wire ir_load,
    input  wire flush,
    input  wire [3:0] pc_in,
    input  wire [11:0] instruction_in,
    output reg  [11:0] instruction_out,
    output reg  [3:0] pc_out,
    output reg  valid_out
);
    // Asynchronous reset: active high
    always @(posedge clk or posedge rst) begin
        if (rst || flush) begin
            instruction_out <= 12'hC00; // NOP
            pc_out <= 4'd0;
            valid_out <= 1'b0;
        end else if (ir_load) begin
            instruction_out <= instruction_in;
            pc_out <= pc_in;
            valid_out <= 1'b1;
        end
    end
endmodule