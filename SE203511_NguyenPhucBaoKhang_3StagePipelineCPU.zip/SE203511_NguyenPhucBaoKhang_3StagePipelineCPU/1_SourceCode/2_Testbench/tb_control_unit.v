`timescale 1ns / 1ps
// FILE: tb_control_unit.v
module tb_control_unit;
    reg [3:0] opcode = 4'b0000;
    reg ex_jump_en = 0;
    reg ex_jz_en = 0;
    reg zero_flag = 0;
    
    wire [2:0] op_sel;
    wire alu_src_sel, wb_sel, reg_write, mem_write;
    wire zero_we, carry_we, jump_en, jz_en;
    wire pc_sel, flush;
    
    integer errors = 0;
    integer tests = 0;

    control_unit DUT (
        .opcode(opcode),
        .alu_ctrl(op_sel), .alu_src_sel(alu_src_sel), .wb_sel(wb_sel),
        .reg_we(reg_write), .mem_we(mem_write), .zero_we(zero_we),
        .carry_we(carry_we), .is_jmp(jump_en), .is_jz(jz_en),
        .ex_is_jmp(ex_jump_en), .ex_is_jz(ex_jz_en), .zero_flag(zero_flag),
        .pc_sel(pc_sel), .flush(flush)
    );

    wire [10:0] signals = {op_sel, alu_src_sel, wb_sel, reg_write, mem_write, zero_we, carry_we, jump_en, jz_en};

    task check_op;
        input [8*6:1] name;
        input [3:0] op;
        input [10:0] expected;
        begin
            opcode = op; #1;
            tests = tests + 1;
            if (signals === expected)
                $display("PASS %0s op_sel=%0d src=%b wb=%b rw=%b mw=%b zw=%b cw=%b jmp=%b jz=%b", 
                         name, op_sel, alu_src_sel, wb_sel, reg_write, mem_write, zero_we, carry_we, jump_en, jz_en);
            else begin
                $display("FAIL %0s got %b, expected %b", name, signals, expected);
                errors = errors + 1;
            end
        end
    endtask

    task check_branch;
        input [8*24:1] name;
        input jmp, jz, z;
        input exp_pc_sel;
        begin
            tests = tests + 1;
            ex_jump_en = jmp; ex_jz_en = jz; zero_flag = z; #1;
            if (pc_sel === exp_pc_sel && flush === exp_pc_sel)
                $display("PASS %0s pc_sel=%b flush=%b", name, pc_sel, flush);
            else begin
                $display("FAIL %0s pc_sel=%b flush=%b (expected %b)", name, pc_sel, flush, exp_pc_sel);
                errors = errors + 1;
            end
        end
    endtask

    initial begin
        $display("\n===== tb_control_unit: control unit test =====");
        $display("-- Part A: decoder (DECODE stage) --");
        // Expected format: {op_sel, alu_src_sel, wb_sel, reg_write, mem_write, zero_we, carry_we, jump_en, jz_en}
        check_op("ADD   ", 4'b0000, {3'd0, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b1, 1'b0, 1'b0});
        check_op("SUB   ", 4'b0001, {3'd1, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b1, 1'b0, 1'b0});
        check_op("AND   ", 4'b0010, {3'd2, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0});
        check_op("OR    ", 4'b0011, {3'd3, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0});
        check_op("XOR   ", 4'b0100, {3'd4, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0});
        check_op("NOT   ", 4'b0101, {3'd5, 1'b0, 1'b0, 1'b1, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0});
        check_op("LDI   ", 4'b0110, {3'd6, 1'b1, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0});
        check_op("MOV   ", 4'b0111, {3'd6, 1'b0, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0});
        check_op("LOAD  ", 4'b1000, {3'd6, 1'b1, 1'b1, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0});
        check_op("STORE ", 4'b1001, {3'd6, 1'b1, 1'b0, 1'b0, 1'b1, 1'b0, 1'b0, 1'b0, 1'b0});
        check_op("JMP   ", 4'b1010, {3'd0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1, 1'b0});
        check_op("JZ    ", 4'b1011, {3'd0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b1});
        check_op("RES-C ", 4'b1100, {3'd0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0, 1'b0});
        
        $display("\n-- Part B: branch unit (EXECUTE stage)--");
        check_branch("no jump instruction     ", 0, 0, 0, 0);
        check_branch("no jump, Zero = 1       ", 0, 0, 1, 0);
        check_branch("JMP                     ", 1, 0, 0, 1);
        check_branch("JMP (Zero = 1)          ", 1, 0, 1, 1);
        check_branch("JZ with Zero = 0        ", 0, 1, 0, 0);
        check_branch("JZ with Zero = 1        ", 0, 1, 1, 1);
        
        if (errors == 0)
            $display("tb_control_unit PASSED: %0d of %0d checks OK\n", tests, tests);
        else
            $display("tb_control_unit FAILED: %0d of %0d checks failed\n", errors, tests);
        $finish;
    end
endmodule