`timescale 1ns / 1ps
// FILE: control_unit.v
// Single optimized module with dataflow approach
module control_unit (
    // DECODE stage inputs/outputs
    input  wire [3:0] opcode,
    output wire [2:0] alu_ctrl,
    output wire alu_src_sel,
    output wire wb_sel,
    output wire reg_we,
    output wire mem_we,
    output wire zero_we,
    output wire carry_we,
    output wire is_jmp,
    output wire is_jz,
    
    // EXECUTE stage inputs/outputs (branch unit)
    input  wire ex_is_jmp,
    input  wire ex_is_jz,
    input  wire zero_flag,
    output wire pc_sel,
    output wire flush
);

    // 1. Decode instruction groups
    wire is_add   = (opcode == 4'b0000);
    wire is_sub   = (opcode == 4'b0001);
    wire is_logic = (opcode >= 4'b0010 && opcode <= 4'b0101); // AND, OR, XOR, NOT
    wire is_ldi   = (opcode == 4'b0110);
    wire is_mov   = (opcode == 4'b0111);
    wire is_ld    = (opcode == 4'b1000);
    wire is_st    = (opcode == 4'b1001);

    // 2. Assign control signals
    assign alu_ctrl = (is_add) ? 3'd0 : (is_sub) ? 3'd1 : 
                      (opcode == 4'b0010) ? 3'd2 : (opcode == 4'b0011) ? 3'd3 : 
                      (opcode == 4'b0100) ? 3'd4 : (opcode == 4'b0101) ? 3'd5 : 
                      (is_ldi | is_mov | is_ld | is_st) ? 3'd6 : 3'd0;

    assign alu_src_sel = is_ldi | is_ld | is_st;
    assign wb_sel      = is_ld;
    assign reg_we      = is_add | is_sub | is_logic | is_ldi | is_mov | is_ld;
    assign mem_we      = is_st;
    assign zero_we     = is_add | is_sub | is_logic;
    assign carry_we    = is_add | is_sub;
    assign is_jmp      = (opcode == 4'b1010);
    assign is_jz       = (opcode == 4'b1011);

    // 3. Branch Unit logic (EX stage)
    assign pc_sel      = ex_is_jmp | (ex_is_jz & zero_flag);
    assign flush       = pc_sel;

endmodule