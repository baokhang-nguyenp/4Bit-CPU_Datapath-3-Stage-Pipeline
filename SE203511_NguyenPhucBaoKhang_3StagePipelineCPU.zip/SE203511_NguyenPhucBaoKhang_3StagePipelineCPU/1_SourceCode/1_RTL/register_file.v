`timescale 1ns / 1ps
// FILE: register_file.v
module register_file (
    input  wire clk,
    input  wire rst,
    input  wire [1:0] ra,
    input  wire [1:0] rb,
    input  wire [1:0] wa,
    input  wire [3:0] wd,
    input  wire we,
    output reg  [3:0] qa,
    output reg  [3:0] qb
);
    reg [3:0] r0, r1, r2, r3;
    
    // Asynchronous reset: active high
    always @(posedge clk or posedge rst) begin
        if (rst) begin
            r0 <= 4'b0000; r1 <= 4'b0000;
            r2 <= 4'b0000; r3 <= 4'b0000;
        end else if (we) begin
            case (wa)
                2'd0: r0 <= wd;
                2'd1: r1 <= wd;
                2'd2: r2 <= wd;
                2'd3: r3 <= wd;
            endcase
        end
    end
    
    // Combinational read ports
    always @(*) begin
        case (ra)
            2'd0: qa = r0; 2'd1: qa = r1; 2'd2: qa = r2; 2'd3: qa = r3;
        endcase
    end
    
    always @(*) begin
        case (rb)
            2'd0: qb = r0; 2'd1: qb = r1; 2'd2: qb = r2; 2'd3: qb = r3;
        endcase
    end
endmodule