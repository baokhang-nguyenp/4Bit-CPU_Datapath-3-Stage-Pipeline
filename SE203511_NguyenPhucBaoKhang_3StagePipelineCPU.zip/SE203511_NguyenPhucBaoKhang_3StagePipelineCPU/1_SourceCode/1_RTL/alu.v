`timescale 1ns / 1ps
// FILE: alu.v
// Single optimized module with dataflow approach.
// Carry for SUB: 1 when borrow occurs (a < b).
module alu (
    input  wire [3:0] a,
    input  wire [3:0] b,
    input  wire [2:0] alu_ctrl,
    output wire [3:0] result,
    output wire carry,
    output wire zero
);
    // Optimize hardware usage for addition and subtraction
    wire [4:0] sum_ext = a + b;
    wire [4:0] sub_ext = a - b;
    
    // Carry for addition (overflow), Carry for subtraction (borrow when a < b)
    wire add_carry = sum_ext[4];
    wire sub_carry = (a < b); 

    // MUX for selecting ALU result
    assign result = (alu_ctrl == 3'd0) ? sum_ext[3:0] :
                    (alu_ctrl == 3'd1) ? sub_ext[3:0] :
                    (alu_ctrl == 3'd2) ? (a & b) :
                    (alu_ctrl == 3'd3) ? (a | b) :
                    (alu_ctrl == 3'd4) ? (a ^ b) :
                    (alu_ctrl == 3'd5) ? (~a) : b; // Default is PASS (6)
                    
    // Assign carry based on operation
    assign carry = (alu_ctrl == 3'd0) ? add_carry :
                   (alu_ctrl == 3'd1) ? sub_carry : 1'b0;
                   
    // Zero detection
    assign zero = (result == 4'b0000);
endmodule